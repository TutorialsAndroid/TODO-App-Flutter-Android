package com.example.todo;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
